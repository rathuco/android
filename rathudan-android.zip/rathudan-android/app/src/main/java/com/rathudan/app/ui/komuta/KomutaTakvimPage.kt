package com.rathudan.app.ui.komuta

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.CalendarEvent
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun KomutaTakvimPage(state: KomutaState, vm: KomutaViewModel) {
    var currentMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(LocalDate.now()) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CalendarEvent?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    val eventsByDate = state.calendarEvents.groupBy { it.date }
    val selectedEvents = selectedDate?.let { eventsByDate[it.toString()] } ?: emptyList()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            // Month header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { currentMonth = currentMonth.minusMonths(1) }) {
                    Icon(Icons.Default.ChevronLeft, "Önceki", tint = R.T2)
                }
                Text(
                    "${currentMonth.month.getDisplayName(TextStyle.FULL, Locale("tr"))} ${currentMonth.year}",
                    color = R.T1, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                IconButton(onClick = { currentMonth = currentMonth.plusMonths(1) }) {
                    Icon(Icons.Default.ChevronRight, "Sonraki", tint = R.T2)
                }
            }

            // Day headers
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pa").forEach { d ->
                    Text(
                        d, color = R.T3, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f).padding(vertical = 4.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Calendar grid
            val firstDay = currentMonth.atDay(1)
            val startOffset = (firstDay.dayOfWeek.value - 1) // Monday = 0
            val daysInMonth = currentMonth.lengthOfMonth()

            for (week in 0..5) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (dow in 0..6) {
                        val dayNum = week * 7 + dow - startOffset + 1
                        if (dayNum in 1..daysInMonth) {
                            val date = currentMonth.atDay(dayNum)
                            val hasEvents = eventsByDate.containsKey(date.toString())
                            val isSelected = selectedDate == date
                            val isToday = date == LocalDate.now()

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        when {
                                            isSelected -> R.Red.copy(alpha = 0.2f)
                                            isToday -> R.Card
                                            else -> Color.Transparent
                                        }
                                    )
                                    .then(
                                        if (isSelected) Modifier.border(1.dp, R.Red, RoundedCornerShape(6.dp))
                                        else Modifier
                                    )
                                    .clickable { selectedDate = date },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "$dayNum",
                                        color = when {
                                            isSelected -> R.Red
                                            isToday -> R.T1
                                            else -> R.T2
                                        },
                                        fontSize = 12.sp,
                                        fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (hasEvents) {
                                        Box(
                                            modifier = Modifier.size(4.dp)
                                                .clip(CircleShape)
                                                .background(R.Red)
                                        )
                                    }
                                }
                            }
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Selected date events
            Text(
                selectedDate?.toString() ?: "Tarih seçin",
                color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Spacer(Modifier.height(8.dp))

            if (selectedEvents.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(R.Card)
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Bu gün için etkinlik yok", color = R.T3, fontSize = 11.sp)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(selectedEvents, key = { it.id }) { event ->
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(R.Card)
                                .border(1.dp, R.Border, RoundedCornerShape(8.dp))
                                .clickable { editing = event; showDialog = true }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(8.dp).clip(CircleShape)
                                    .background(try { Color(android.graphics.Color.parseColor(event.color)) } catch (_: Exception) { R.Red })
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(event.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                if (event.time.isNotEmpty()) {
                                    Text(event.time, color = R.T3, fontSize = 10.sp)
                                }
                                if (event.description.isNotEmpty()) {
                                    Text(event.description, color = R.T2, fontSize = 11.sp, maxLines = 2)
                                }
                            }
                            IconButton(onClick = { deleteTarget = event.id }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { editing = null; showDialog = true })
        }

        if (showDialog) {
            CalendarEventDialog(
                initial = editing,
                defaultDate = selectedDate?.toString() ?: LocalDate.now().toString(),
                onSave = { vm.saveCalendarEvent(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Etkinliği Sil", message = "Bu etkinlik silinecek.",
                onConfirm = { vm.deleteCalendarEvent(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun CalendarEventDialog(
    initial: CalendarEvent?,
    defaultDate: String,
    onSave: (CalendarEvent) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var date by remember { mutableStateOf(initial?.date ?: defaultDate) }
    var time by remember { mutableStateOf(initial?.time ?: "") }
    var color by remember { mutableStateOf(initial?.color ?: "#C2212E") }

    val colors = listOf("#C2212E", "#0A66C2", "#22C55E", "#F59E0B", "#8B5CF6", "#E1306C")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni Etkinlik" else "Etkinlik Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DarkField(title, { title = it }, "Başlık")
                DarkField(desc, { desc = it }, "Açıklama", singleLine = false, minLines = 2)
                DarkField(date, { date = it }, "Tarih (YYYY-MM-DD)")
                DarkField(time, { time = it }, "Saat (HH:MM)")

                Text("Renk", color = R.T3, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colors.forEach { c ->
                        val parsed = try { Color(android.graphics.Color.parseColor(c)) } catch (_: Exception) { R.Red }
                        Box(
                            modifier = Modifier.size(28.dp)
                                .clip(CircleShape)
                                .background(parsed)
                                .then(
                                    if (color == c) Modifier.border(2.dp, Color.White, CircleShape)
                                    else Modifier
                                )
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = (initial ?: CalendarEvent()).copy(
                    title = title, description = desc, date = date, time = time, color = color
                )
                onSave(e)
            }, enabled = title.isNotBlank()) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
