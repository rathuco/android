package com.rathudan.app.di

import android.content.Context
import androidx.room.Room
import com.rathudan.app.data.local.RathudanDao
import com.rathudan.app.data.local.RathudanDatabase
import com.rathudan.app.data.remote.SupabaseProvider
import com.rathudan.app.data.repository.RathudanRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideSupabaseClient(): SupabaseClient = SupabaseProvider.client

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): RathudanDatabase {
        return Room.databaseBuilder(
            context,
            RathudanDatabase::class.java,
            "rathudan_db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun provideDao(db: RathudanDatabase): RathudanDao = db.dao()

    @Provides
    @Singleton
    fun provideRepository(
        client: SupabaseClient,
        dao: RathudanDao
    ): RathudanRepository = RathudanRepository(client, dao)
}
