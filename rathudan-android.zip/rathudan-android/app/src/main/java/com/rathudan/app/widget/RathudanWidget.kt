package com.rathudan.app.widget

import android.content.Context
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.background
import androidx.glance.unit.ColorProvider
import com.rathudan.app.MainActivity

class RathudanWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(day = android.graphics.Color.parseColor("#16161C"), night = android.graphics.Color.parseColor("#16161C"))
                    .padding(16.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "R RATHUDAN",
                    style = TextStyle(
                        color = ColorProvider(
                            color = androidx.compose.ui.graphics.Color(0xFFC2212E)
                        ),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = GlanceModifier.height(8.dp))
                Text(
                    "Komuta Merkezi",
                    style = TextStyle(
                        color = ColorProvider(
                            color = androidx.compose.ui.graphics.Color(0xFF94949F)
                        ),
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

class RathudanWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = RathudanWidget()
}
