package com.rathudan.app.ui.icerik

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.Account
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun IcerikHesaplarPage(state: IcerikState, vm: IcerikViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Hesaplar", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))

            if (state.accounts.isEmpty()) {
                EmptyState("Henüz hesap eklenmedi")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.accounts, key = { it.id }) { acc ->
                        val contentCount = state.contents.count { it.accountId == acc.id }
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(R.Card)
                                .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(R.platformBg(acc.platform)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    R.platformTag(acc.platform),
                                    color = R.platformColor(acc.platform),
                                    fontWeight = FontWeight.Black, fontSize = 14.sp
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(acc.accountName, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("@${acc.username}", color = R.T3, fontSize = 11.sp)
                                Text("$contentCount içerik", color = R.T3, fontSize = 10.sp)
                            }
                            IconButton(onClick = { deleteTarget = acc.id }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { showDialog = true })
        }

        if (showDialog) {
            AccountDialog(
                onSave = { vm.addAccount(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Hesabı Sil", message = "Bu hesap ve ilişkili verileri etkilenebilir.",
                onConfirm = { vm.deleteAccount(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun AccountDialog(onSave: (Account) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("instagram") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yeni Hesap", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Platform", color = R.T3, fontSize = 10.sp)
                ChipRow(
                    options = listOf("instagram" to "Instagram", "linkedin" to "LinkedIn", "youtube" to "YouTube"),
                    selected = platform, onSelect = { platform = it },
                    colorFn = { R.platformColor(it) }
                )
                DarkField(name, { name = it }, "Hesap Adı")
                DarkField(username, { username = it }, "Kullanıcı adı")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(Account(platform = platform, accountName = name, username = username))
            }, enabled = name.isNotBlank() && username.isNotBlank()) {
                Text("Ekle", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
