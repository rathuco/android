package com.rathudan.app.ui.icerik

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun IcerikTakvimPage(state: IcerikState, vm: IcerikViewModel) {
    var currentMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(LocalDate.now()) }

    // Group contents by date
    val contentsByDate = state.contents
        .filter { it.date != null }
        .groupBy { it.date!! }

    val selectedContents = selectedDate?.let { contentsByDate[it.toString()] } ?: emptyList()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Yayın Takvimi", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))

        // Month nav
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { currentMonth = currentMonth.minusMonths(1) }) {
                Icon(Icons.Default.ChevronLeft, "Önceki", tint = R.T2)
            }
            Text(
                "${currentMonth.month.getDisplayName(TextStyle.FULL, Locale("tr"))} ${currentMonth.year}",
                color = R.T1, fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            IconButton(onClick = { currentMonth = currentMonth.plusMonths(1) }) {
                Icon(Icons.Default.ChevronRight, "Sonraki", tint = R.T2)
            }
        }

        // Day headers
        Row(Modifier.fillMaxWidth()) {
            listOf("Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pa").forEach { d ->
                Text(d, color = R.T3, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f).padding(vertical = 4.dp), textAlign = TextAlign.Center)
            }
        }

        // Grid
        val firstDay = currentMonth.atDay(1)
        val startOffset = firstDay.dayOfWeek.value - 1
        val daysInMonth = currentMonth.lengthOfMonth()

        for (week in 0..5) {
            Row(Modifier.fillMaxWidth()) {
                for (dow in 0..6) {
                    val dayNum = week * 7 + dow - startOffset + 1
                    if (dayNum in 1..daysInMonth) {
                        val date = currentMonth.atDay(dayNum)
                        val dateStr = date.toString()
                        val hasContent = contentsByDate.containsKey(dateStr)
                        val isSelected = selectedDate == date
                        val isToday = date == LocalDate.now()
                        val dayContents = contentsByDate[dateStr] ?: emptyList()

                        Box(
                            modifier = Modifier.weight(1f).aspectRatio(1f).padding(1.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(when {
                                    isSelected -> R.Red.copy(alpha = 0.15f)
                                    isToday -> R.Card
                                    else -> Color.Transparent
                                })
                                .then(if (isSelected) Modifier.border(1.dp, R.Red, RoundedCornerShape(4.dp)) else Modifier)
                                .clickable { selectedDate = date },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "$dayNum", fontSize = 11.sp,
                                    color = when {
                                        isSelected -> R.Red
                                        isToday -> R.T1
                                        else -> R.T2
                                    },
                                    fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                if (hasContent) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                                        dayContents.take(3).forEach { c ->
                                            Box(Modifier.size(4.dp).clip(CircleShape)
                                                .background(R.platformColor(c.platform)))
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Selected date detail
        Text(
            selectedDate?.toString() ?: "Tarih seçin",
            color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
        Spacer(Modifier.height(8.dp))

        if (selectedContents.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(R.Card)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Bu gün için planlanmış içerik yok", color = R.T3, fontSize = 11.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(selectedContents, key = { it.id }) { content ->
                    val acc = state.accounts.find { it.id == content.accountId }
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(R.Card)
                            .border(1.dp, R.Border, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(6.dp).clip(CircleShape)
                                .background(R.platformColor(content.platform))
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                RBadge(R.platformTag(content.platform), R.platformColor(content.platform), R.platformBg(content.platform))
                                RBadge(R.statusLabel(content.status), R.statusColor(content.status))
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(content.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            acc?.let { Text("@${it.username}", color = R.T3, fontSize = 10.sp) }
                        }
                    }
                }
            }
        }
    }
}
