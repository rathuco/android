package com.rathudan.app.data.repository

import com.rathudan.app.data.local.RathudanDao
import com.rathudan.app.data.local.*
import com.rathudan.app.data.model.*
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RathudanRepository @Inject constructor(
    private val client: SupabaseClient,
    private val dao: RathudanDao
) {
    // ══════ AUTH ══════

    val currentUserId: String?
        get() = client.auth.currentUserOrNull()?.id

    suspend fun signIn(email: String, password: String) {
        client.auth.signInWith(Email) {
            this.email = email
            this.password = password
        }
    }

    suspend fun signUp(email: String, password: String) {
        client.auth.signUpWith(Email) {
            this.email = email
            this.password = password
        }
    }

    suspend fun signOut() {
        client.auth.signOut()
    }

    fun isLoggedIn(): Boolean = client.auth.currentUserOrNull() != null

    // ══════ GOALS ══════

    suspend fun fetchGoals(): List<Goal> {
        val uid = currentUserId ?: return emptyList()
        val goals = client.from("goals").select {
            filter { eq("user_id", uid) }
            order("created_at", Order.DESCENDING)
        }.decodeList<Goal>()
        // Cache to Room
        dao.clearGoals(uid)
        dao.insertGoals(goals.map {
            GoalEntity(it.id, it.userId, it.title, it.description, it.deadline,
                it.progress, it.status, it.priority, it.createdAt, it.updatedAt)
        })
        return goals
    }

    suspend fun upsertGoal(goal: Goal): Goal {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = goal.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("goals").insert(withUser) { select() }.decodeSingle<Goal>()
        } else {
            client.from("goals").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<Goal>()
        }
    }

    suspend fun deleteGoal(id: String) {
        client.from("goals").delete { filter { eq("id", id) } }
    }

    // ══════ JOURNAL ══════

    suspend fun fetchJournal(): List<JournalEntry> {
        val uid = currentUserId ?: return emptyList()
        val entries = client.from("journal_entries").select {
            filter { eq("user_id", uid) }
            order("date", Order.DESCENDING)
        }.decodeList<JournalEntry>()
        dao.clearJournal(uid)
        dao.insertJournal(entries.map {
            JournalEntity(it.id, it.userId, it.date, it.content, it.mood, it.tags, it.createdAt, it.updatedAt)
        })
        return entries
    }

    suspend fun upsertJournalEntry(entry: JournalEntry): JournalEntry {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = entry.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("journal_entries").insert(withUser) { select() }.decodeSingle<JournalEntry>()
        } else {
            client.from("journal_entries").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<JournalEntry>()
        }
    }

    suspend fun deleteJournalEntry(id: String) {
        client.from("journal_entries").delete { filter { eq("id", id) } }
    }

    // ══════ PLANS ══════

    suspend fun fetchPlansWithDetails(): List<PlanWithDetails> {
        val uid = currentUserId ?: return emptyList()
        val plans = client.from("plans").select {
            filter { eq("user_id", uid) }
            order("created_at", Order.ASCENDING)
        }.decodeList<Plan>()

        if (plans.isEmpty()) return emptyList()

        val planIds = plans.map { it.id }
        val steps = client.from("roadmap_steps").select {
            filter { isIn("plan_id", planIds) }
            order("sort_order", Order.ASCENDING)
        }.decodeList<RoadmapStep>()

        val notes = client.from("notes").select {
            filter { isIn("plan_id", planIds) }
            order("sort_order", Order.ASCENDING)
        }.decodeList<Note>()

        // Cache
        dao.clearPlans(uid)
        dao.insertPlans(plans.map { PlanEntity(it.id, it.userId, it.title, it.createdAt, it.updatedAt) })
        dao.insertRoadmapSteps(steps.map {
            RoadmapStepEntity(it.id, it.planId, it.title, it.description, it.done, it.sortOrder, it.createdAt)
        })
        dao.insertNotes(notes.map {
            NoteEntity(it.id, it.planId, it.title, it.content, it.source, it.sortOrder, it.createdAt)
        })

        val stepMap = steps.groupBy { it.planId }
        val noteMap = notes.groupBy { it.planId }
        return plans.map { PlanWithDetails(it, stepMap[it.id] ?: emptyList(), noteMap[it.id] ?: emptyList()) }
    }

    suspend fun insertPlan(title: String): Plan {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        return client.from("plans").insert(mapOf("title" to title, "user_id" to uid)) {
            select()
        }.decodeSingle<Plan>()
    }

    suspend fun deletePlan(id: String) {
        client.from("plans").delete { filter { eq("id", id) } }
    }

    suspend fun upsertRoadmapStep(step: RoadmapStep): RoadmapStep {
        return if (step.id.isEmpty()) {
            client.from("roadmap_steps").insert(step) { select() }.decodeSingle<RoadmapStep>()
        } else {
            client.from("roadmap_steps").update(step) {
                filter { eq("id", step.id) }
                select()
            }.decodeSingle<RoadmapStep>()
        }
    }

    suspend fun deleteRoadmapStep(id: String) {
        client.from("roadmap_steps").delete { filter { eq("id", id) } }
    }

    suspend fun upsertNote(note: Note): Note {
        return if (note.id.isEmpty()) {
            client.from("notes").insert(note) { select() }.decodeSingle<Note>()
        } else {
            client.from("notes").update(note) {
                filter { eq("id", note.id) }
                select()
            }.decodeSingle<Note>()
        }
    }

    suspend fun deleteNote(id: String) {
        client.from("notes").delete { filter { eq("id", id) } }
    }

    // ══════ NOTE PAGES ══════

    suspend fun fetchNotePages(): List<NotePage> {
        val uid = currentUserId ?: return emptyList()
        val pages = client.from("note_pages").select {
            filter { eq("user_id", uid) }
            order("sort_order", Order.ASCENDING)
        }.decodeList<NotePage>()
        dao.clearNotePages(uid)
        dao.insertNotePages(pages.map {
            NotePageEntity(it.id, it.userId, it.title, it.description, it.content, it.source, it.sortOrder, it.createdAt, it.updatedAt)
        })
        return pages
    }

    suspend fun upsertNotePage(page: NotePage): NotePage {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = page.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("note_pages").insert(withUser) { select() }.decodeSingle<NotePage>()
        } else {
            client.from("note_pages").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<NotePage>()
        }
    }

    suspend fun deleteNotePage(id: String) {
        client.from("note_pages").delete { filter { eq("id", id) } }
    }

    // ══════ CALENDAR ══════

    suspend fun fetchCalendarEvents(): List<CalendarEvent> {
        val uid = currentUserId ?: return emptyList()
        val events = client.from("calendar_events").select {
            filter { eq("user_id", uid) }
            order("date", Order.ASCENDING)
        }.decodeList<CalendarEvent>()
        dao.clearCalendarEvents(uid)
        dao.insertCalendarEvents(events.map {
            CalendarEventEntity(it.id, it.userId, it.title, it.description, it.date, it.time, it.color, it.createdAt)
        })
        return events
    }

    suspend fun upsertCalendarEvent(event: CalendarEvent): CalendarEvent {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = event.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("calendar_events").insert(withUser) { select() }.decodeSingle<CalendarEvent>()
        } else {
            client.from("calendar_events").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<CalendarEvent>()
        }
    }

    suspend fun deleteCalendarEvent(id: String) {
        client.from("calendar_events").delete { filter { eq("id", id) } }
    }

    // ══════ ACCOUNTS ══════

    suspend fun fetchAccounts(): List<Account> {
        val uid = currentUserId ?: return emptyList()
        val items = client.from("accounts").select {
            filter { eq("user_id", uid) }
            order("created_at", Order.ASCENDING)
        }.decodeList<Account>()
        dao.clearAccounts(uid)
        dao.insertAccounts(items.map {
            AccountEntity(it.id, it.userId, it.platform, it.accountName, it.username, it.createdAt)
        })
        return items
    }

    suspend fun insertAccount(account: Account): Account {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = account.copy(userId = uid)
        return client.from("accounts").insert(withUser) { select() }.decodeSingle<Account>()
    }

    suspend fun deleteAccount(id: String) {
        client.from("accounts").delete { filter { eq("id", id) } }
    }

    // ══════ CONTENTS ══════

    suspend fun fetchContents(): List<Content> {
        val uid = currentUserId ?: return emptyList()
        val items = client.from("contents").select {
            filter { eq("user_id", uid) }
            order("created_at", Order.DESCENDING)
        }.decodeList<Content>()
        dao.clearContents(uid)
        dao.insertContents(items.map {
            ContentEntity(it.id, it.userId, it.accountId, it.platform, it.title, it.description,
                it.format, it.hashtags, it.status, it.date, it.createdAt, it.updatedAt)
        })
        return items
    }

    suspend fun upsertContent(content: Content): Content {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = content.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("contents").insert(withUser) { select() }.decodeSingle<Content>()
        } else {
            client.from("contents").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<Content>()
        }
    }

    suspend fun deleteContent(id: String) {
        client.from("contents").delete { filter { eq("id", id) } }
    }

    // ══════ ACCOUNT PLANS ══════

    suspend fun fetchAccountPlans(): List<AccountPlan> {
        val uid = currentUserId ?: return emptyList()
        val items = client.from("account_plans").select {
            filter { eq("user_id", uid) }
            order("pinned", Order.DESCENDING)
            order("sort_order", Order.ASCENDING)
        }.decodeList<AccountPlan>()
        dao.clearAccountPlans(uid)
        dao.insertAccountPlans(items.map {
            AccountPlanEntity(it.id, it.userId, it.accountId, it.category, it.title,
                it.content, it.pinned, it.sortOrder, it.createdAt, it.updatedAt)
        })
        return items
    }

    suspend fun upsertAccountPlan(plan: AccountPlan): AccountPlan {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = plan.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("account_plans").insert(withUser) { select() }.decodeSingle<AccountPlan>()
        } else {
            client.from("account_plans").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<AccountPlan>()
        }
    }

    suspend fun deleteAccountPlan(id: String) {
        client.from("account_plans").delete { filter { eq("id", id) } }
    }

    // ══════ TEMPLATES ══════

    suspend fun fetchTemplates(): List<ContentTemplate> {
        val uid = currentUserId ?: return emptyList()
        val items = client.from("content_templates").select {
            filter { eq("user_id", uid) }
            order("created_at", Order.ASCENDING)
        }.decodeList<ContentTemplate>()
        dao.clearTemplates(uid)
        dao.insertTemplates(items.map {
            ContentTemplateEntity(it.id, it.userId, it.platform, it.name, it.format,
                it.titleTemplate, it.descriptionTemplate, it.hashtags, it.createdAt, it.updatedAt)
        })
        return items
    }

    suspend fun upsertTemplate(tmpl: ContentTemplate): ContentTemplate {
        val uid = currentUserId ?: throw IllegalStateException("Not logged in")
        val withUser = tmpl.copy(userId = uid)
        return if (withUser.id.isEmpty()) {
            client.from("content_templates").insert(withUser) { select() }.decodeSingle<ContentTemplate>()
        } else {
            client.from("content_templates").update(withUser) {
                filter { eq("id", withUser.id) }
                select()
            }.decodeSingle<ContentTemplate>()
        }
    }

    suspend fun deleteTemplate(id: String) {
        client.from("content_templates").delete { filter { eq("id", id) } }
    }
}
