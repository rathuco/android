package com.rathudan.app.ui.komuta

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.JournalEntry
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R
import java.time.LocalDate

@Composable
fun KomutaGunlukPage(state: KomutaState, vm: KomutaViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<JournalEntry?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Günlük", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text("Düşüncelerinizi ve ruh halinizi kaydedin", color = R.T3, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))

            // Mood overview
            if (state.journal.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(R.Card)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("harika", "iyi", "normal", "kotu", "berbat").forEach { mood ->
                        val count = state.journal.count { it.mood == mood }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(R.moodEmoji(mood), fontSize = 18.sp)
                            Text("$count", color = R.T1, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            if (state.journal.isEmpty()) {
                EmptyState("Henüz günlük girişi yok")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.journal, key = { it.id }) { entry ->
                        Column(
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(R.Card)
                                .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                .clickable { editing = entry; showDialog = true }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(R.moodEmoji(entry.mood), fontSize = 18.sp)
                                    Column {
                                        Text(entry.date, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        if (entry.tags.isNotEmpty()) {
                                            Text(entry.tags, color = R.T3, fontSize = 9.sp)
                                        }
                                    }
                                }
                                IconButton(onClick = { deleteTarget = entry.id }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text(entry.content, color = R.T2, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { editing = null; showDialog = true })
        }

        if (showDialog) {
            JournalDialog(
                initial = editing,
                existingDates = state.journal.map { it.date }.toSet(),
                onSave = { vm.saveJournalEntry(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Girişi Sil", message = "Bu günlük girişi silinecek.",
                onConfirm = { vm.deleteJournalEntry(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun JournalDialog(
    initial: JournalEntry?,
    existingDates: Set<String>,
    onSave: (JournalEntry) -> Unit,
    onDismiss: () -> Unit
) {
    var date by remember { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var content by remember { mutableStateOf(initial?.content ?: "") }
    var mood by remember { mutableStateOf(initial?.mood ?: "normal") }
    var tags by remember { mutableStateOf(initial?.tags ?: "") }
    val isDuplicate = initial == null && existingDates.contains(date)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni Giriş" else "Giriş Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DarkField(date, { date = it }, "Tarih (YYYY-MM-DD)")
                if (isDuplicate) {
                    Text("Bu tarih için zaten giriş var!", color = R.Danger, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Text("Ruh hali", color = R.T3, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("harika", "iyi", "normal", "kotu", "berbat").forEach { m ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (mood == m) R.Red.copy(alpha = 0.15f) else Color.Transparent)
                                .border(1.dp, if (mood == m) R.Red else R.Border, RoundedCornerShape(8.dp))
                                .clickable { mood = m }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(R.moodEmoji(m), fontSize = 20.sp)
                        }
                    }
                }

                DarkField(content, { content = it }, "Bugün ne düşünüyorsun?", singleLine = false, minLines = 4)
                DarkField(tags, { tags = it }, "Etiketler (virgülle)")
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val e = (initial ?: JournalEntry()).copy(
                        date = date, content = content, mood = mood, tags = tags
                    )
                    onSave(e)
                },
                enabled = content.isNotBlank() && !isDuplicate
            ) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
