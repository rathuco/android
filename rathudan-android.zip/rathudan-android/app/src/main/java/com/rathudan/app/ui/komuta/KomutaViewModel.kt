package com.rathudan.app.ui.komuta

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rathudan.app.data.model.*
import com.rathudan.app.data.repository.RathudanRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class KomutaState(
    val goals: List<Goal> = emptyList(),
    val plans: List<PlanWithDetails> = emptyList(),
    val notePages: List<NotePage> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    val calendarEvents: List<CalendarEvent> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class KomutaViewModel @Inject constructor(
    private val repo: RathudanRepository
) : ViewModel() {
    private val _state = MutableStateFlow(KomutaState())
    val state: StateFlow<KomutaState> = _state.asStateFlow()

    init { loadAll() }

    fun loadAll() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val goals = repo.fetchGoals()
                val plans = repo.fetchPlansWithDetails()
                val notePages = repo.fetchNotePages()
                val journal = repo.fetchJournal()
                val events = repo.fetchCalendarEvents()
                _state.value = KomutaState(
                    goals = goals, plans = plans, notePages = notePages,
                    journal = journal, calendarEvents = events, isLoading = false
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    // ── Goals ──
    fun saveGoal(goal: Goal) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertGoal(goal)
                val list = _state.value.goals.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(0, saved)
                _state.value = _state.value.copy(goals = list)
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deleteGoal(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteGoal(id)
                _state.value = _state.value.copy(goals = _state.value.goals.filter { it.id != id })
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    // ── Plans ──
    fun addPlan(title: String) {
        viewModelScope.launch {
            try {
                val plan = repo.insertPlan(title)
                val list = _state.value.plans + PlanWithDetails(plan)
                _state.value = _state.value.copy(plans = list)
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deletePlan(id: String) {
        viewModelScope.launch {
            try {
                repo.deletePlan(id)
                _state.value = _state.value.copy(plans = _state.value.plans.filter { it.plan.id != id })
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun saveRoadmapStep(step: RoadmapStep) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertRoadmapStep(step)
                refreshPlans()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deleteRoadmapStep(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteRoadmapStep(id)
                refreshPlans()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun saveNote(note: Note) {
        viewModelScope.launch {
            try {
                repo.upsertNote(note)
                refreshPlans()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deleteNote(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteNote(id)
                refreshPlans()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    private suspend fun refreshPlans() {
        val plans = repo.fetchPlansWithDetails()
        _state.value = _state.value.copy(plans = plans)
    }

    // ── Note Pages ──
    fun saveNotePage(page: NotePage) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertNotePage(page)
                val list = _state.value.notePages.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(saved)
                _state.value = _state.value.copy(notePages = list)
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deleteNotePage(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteNotePage(id)
                _state.value = _state.value.copy(notePages = _state.value.notePages.filter { it.id != id })
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    // ── Journal ──
    fun saveJournalEntry(entry: JournalEntry) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertJournalEntry(entry)
                val list = _state.value.journal.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(0, saved)
                _state.value = _state.value.copy(journal = list)
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deleteJournalEntry(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteJournalEntry(id)
                _state.value = _state.value.copy(journal = _state.value.journal.filter { it.id != id })
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    // ── Calendar ──
    fun saveCalendarEvent(event: CalendarEvent) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertCalendarEvent(event)
                val list = _state.value.calendarEvents.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(saved)
                _state.value = _state.value.copy(calendarEvents = list.sortedBy { it.date })
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun deleteCalendarEvent(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteCalendarEvent(id)
                _state.value = _state.value.copy(
                    calendarEvents = _state.value.calendarEvents.filter { it.id != id }
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }
}
