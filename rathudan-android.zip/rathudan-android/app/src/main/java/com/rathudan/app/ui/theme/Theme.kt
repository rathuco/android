package com.rathudan.app.ui.theme

import android.app.Activity
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// Rathudan Brand Colors
object R {
    val Red = Color(0xFFC2212E)
    val RedDark = Color(0xFF9A1A24)
    val RedGlow = Color(0x40C2212E)
    val Bg = Color(0xFF08080A)
    val Side = Color(0xFF0C0C10)
    val Card = Color(0xFF16161C)
    val CardHover = Color(0xFF1C1C24)
    val Border = Color(0xFF24242E)
    val T1 = Color(0xFFF0F0F2)
    val T2 = Color(0xFF94949F)
    val T3 = Color(0xFF58586A)
    val Ig = Color(0xFFE1306C)
    val IgBg = Color(0x14E1306C)
    val Li = Color(0xFF0A66C2)
    val LiBg = Color(0x140A66C2)
    val Yt = Color(0xFFFF0000)
    val YtBg = Color(0x14FF0000)
    val Ok = Color(0xFF22C55E)
    val OkBg = Color(0x1422C55E)
    val Warn = Color(0xFFF59E0B)
    val WarnBg = Color(0x14F59E0B)
    val Danger = Color(0xFFEF4444)
    val Purple = Color(0xFF8B5CF6)
    val PurpleBg = Color(0x148B5CF6)

    fun platformColor(platform: String): Color = when (platform) {
        "instagram" -> Ig
        "linkedin" -> Li
        "youtube" -> Yt
        else -> T3
    }

    fun platformBg(platform: String): Color = when (platform) {
        "instagram" -> IgBg
        "linkedin" -> LiBg
        "youtube" -> YtBg
        else -> Card
    }

    fun platformTag(platform: String): String = when (platform) {
        "instagram" -> "IG"
        "linkedin" -> "LI"
        "youtube" -> "YT"
        else -> "?"
    }

    fun statusColor(status: String): Color = when (status) {
        "taslak" -> Warn
        "hazir" -> Li
        "yayinlandi" -> Ok
        else -> T3
    }

    fun statusLabel(status: String): String = when (status) {
        "taslak" -> "Taslak"
        "hazir" -> "Hazır"
        "yayinlandi" -> "Yayınlandı"
        else -> status
    }

    fun priorityColor(priority: String): Color = when (priority) {
        "dusuk" -> T3
        "normal" -> Li
        "yuksek" -> Warn
        "kritik" -> Danger
        else -> T3
    }

    fun priorityLabel(priority: String): String = when (priority) {
        "dusuk" -> "Düşük"
        "normal" -> "Normal"
        "yuksek" -> "Yüksek"
        "kritik" -> "Kritik"
        else -> priority
    }

    fun goalStatusColor(status: String): Color = when (status) {
        "aktif" -> Warn
        "tamamlandi" -> Ok
        "iptal" -> Danger
        else -> T3
    }

    fun goalStatusLabel(status: String): String = when (status) {
        "aktif" -> "Aktif"
        "tamamlandi" -> "Tamamlandı"
        "iptal" -> "İptal"
        else -> status
    }

    fun moodEmoji(mood: String): String = when (mood) {
        "harika" -> "🔥"
        "iyi" -> "😊"
        "normal" -> "😐"
        "kotu" -> "😔"
        "berbat" -> "😞"
        else -> "—"
    }

    fun categoryColor(cat: String): Color = when (cat) {
        "strateji" -> Red
        "hedef_kitle" -> Purple
        "icerik_stratejisi" -> Ok
        "ton_ve_dil" -> Warn
        "referans" -> Li
        else -> T3
    }

    fun categoryLabel(cat: String): String = when (cat) {
        "strateji" -> "Strateji"
        "hedef_kitle" -> "Hedef Kitle"
        "icerik_stratejisi" -> "İçerik Stratejisi"
        "ton_ve_dil" -> "Ton & Dil"
        "referans" -> "Referans"
        "diger" -> "Diğer"
        else -> cat
    }
}

private val DarkColorScheme = darkColorScheme(
    primary = R.Red,
    onPrimary = Color.White,
    secondary = R.Li,
    background = R.Bg,
    surface = R.Card,
    surfaceVariant = R.Side,
    onBackground = R.T1,
    onSurface = R.T1,
    onSurfaceVariant = R.T2,
    outline = R.Border,
    error = R.Danger,
    onError = Color.White
)

@Composable
fun RathudanTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = R.Bg.toArgb()
            window.navigationBarColor = R.Bg.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
