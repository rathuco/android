package com.rathudan.app.ui.komuta

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun KomutaDashPage(state: KomutaState, vm: KomutaViewModel) {
    val activeGoals = state.goals.count { it.status == "aktif" }
    val completedGoals = state.goals.count { it.status == "tamamlandi" }
    val totalPlans = state.plans.size
    val totalNotes = state.notePages.size
    val journalCount = state.journal.size
    val upcomingEvents = state.calendarEvents.size
    val avgProgress = if (state.goals.isNotEmpty())
        state.goals.sumOf { it.progress } / state.goals.size else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Text("Komuta Merkezi", color = R.T1, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text("Tüm verileriniz bir bakışta", color = R.T3, fontSize = 12.sp)

        // Stats row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard("Aktif Hedef", "$activeGoals", R.Warn, Modifier.weight(1f))
            StatCard("Tamamlanan", "$completedGoals", R.Ok, Modifier.weight(1f))
            StatCard("Plan", "$totalPlans", R.Li, Modifier.weight(1f))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard("Not Sayfası", "$totalNotes", R.Purple, Modifier.weight(1f))
            StatCard("Günlük", "$journalCount", R.Ig, Modifier.weight(1f))
            StatCard("Etkinlik", "$upcomingEvents", R.Red, Modifier.weight(1f))
        }

        // Progress overview
        if (state.goals.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(R.Card)
                    .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Hedef İlerleme", color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Ortalama: %$avgProgress", color = R.T3, fontSize = 11.sp)
                RProgressBar(progress = avgProgress / 100f)

                Spacer(Modifier.height(6.dp))

                state.goals.filter { it.status == "aktif" }.take(4).forEach { g ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(g.title, color = R.T2, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("%${g.progress}", color = R.T3, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    RProgressBar(progress = g.progress / 100f, color = R.priorityColor(g.priority))
                }
            }
        }

        // Recent journal
        if (state.journal.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(R.Card)
                    .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Son Günlük Girişleri", color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                state.journal.take(3).forEach { j ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(j.date, color = R.T3, fontSize = 10.sp)
                        Text(R.moodEmoji(j.mood), fontSize = 14.sp)
                    }
                    Text(
                        j.content.take(80) + if (j.content.length > 80) "..." else "",
                        color = R.T2, fontSize = 11.sp
                    )
                }
            }
        }
    }
}
