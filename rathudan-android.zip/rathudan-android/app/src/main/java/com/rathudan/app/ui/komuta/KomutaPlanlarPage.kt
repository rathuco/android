package com.rathudan.app.ui.komuta

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.*
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun KomutaPlanlarPage(state: KomutaState, vm: KomutaViewModel) {
    var selectedPlanId by remember { mutableStateOf<String?>(null) }
    var showNewPlan by remember { mutableStateOf(false) }
    var newPlanTitle by remember { mutableStateOf("") }
    var deletePlanId by remember { mutableStateOf<String?>(null) }

    val selected = state.plans.find { it.plan.id == selectedPlanId }

    Box(modifier = Modifier.fillMaxSize()) {
        if (selected == null) {
            // Plan list
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text("Planlar", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))

                if (showNewPlan) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DarkField(newPlanTitle, { newPlanTitle = it }, "Plan adı", modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            if (newPlanTitle.isNotBlank()) {
                                vm.addPlan(newPlanTitle)
                                newPlanTitle = ""; showNewPlan = false
                            }
                        }) {
                            Icon(Icons.Default.Check, "Ekle", tint = R.Ok)
                        }
                        IconButton(onClick = { showNewPlan = false; newPlanTitle = "" }) {
                            Icon(Icons.Default.Close, "İptal", tint = R.T3)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                if (state.plans.isEmpty()) {
                    EmptyState("Henüz plan yok")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(state.plans, key = { it.plan.id }) { pwd ->
                            val doneCount = pwd.roadmap.count { it.done }
                            val totalSteps = pwd.roadmap.size
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(R.Card)
                                    .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                    .clickable { selectedPlanId = pwd.plan.id }
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(pwd.plan.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    IconButton(onClick = { deletePlanId = pwd.plan.id }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    RBadge("$totalSteps adım", R.Li)
                                    RBadge("${pwd.notes.size} not", R.Purple)
                                    if (totalSteps > 0) RBadge("$doneCount/$totalSteps", R.Ok)
                                }
                                if (totalSteps > 0) {
                                    RProgressBar(progress = if (totalSteps > 0) doneCount.toFloat() / totalSteps else 0f, color = R.Ok)
                                }
                            }
                        }
                    }
                }
            }

            Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
                RFab(onClick = { showNewPlan = true })
            }
        } else {
            // Plan detail
            PlanDetailView(pwd = selected, vm = vm, onBack = { selectedPlanId = null })
        }

        deletePlanId?.let { id ->
            ConfirmDialog(
                title = "Planı Sil", message = "Bu plan ve tüm adımları/notları silinecek.",
                onConfirm = { vm.deletePlan(id); deletePlanId = null; if (selectedPlanId == id) selectedPlanId = null },
                onDismiss = { deletePlanId = null }
            )
        }
    }
}

@Composable
fun PlanDetailView(pwd: PlanWithDetails, vm: KomutaViewModel, onBack: () -> Unit) {
    var showStepDialog by remember { mutableStateOf(false) }
    var editingStep by remember { mutableStateOf<RoadmapStep?>(null) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var tab by remember { mutableStateOf("roadmap") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = R.T2)
            }
            Text(pwd.plan.title, color = R.T1, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.height(8.dp))

        // Tabs
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(R.Bg).padding(3.dp)
        ) {
            listOf("roadmap" to "Yol Haritası", "notes" to "Notlar").forEach { (k, l) ->
                Box(
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(5.dp))
                        .background(if (tab == k) R.Red else Color.Transparent)
                        .clickable { tab = k }.padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(l, color = if (tab == k) Color.White else R.T3, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        if (tab == "roadmap") {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(pwd.roadmap, key = { it.id }) { step ->
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(R.Card)
                            .border(1.dp, R.Border, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Checkbox(
                            checked = step.done,
                            onCheckedChange = { vm.saveRoadmapStep(step.copy(done = it)) },
                            colors = CheckboxDefaults.colors(checkedColor = R.Ok, uncheckedColor = R.T3)
                        )
                        Column(modifier = Modifier.weight(1f).clickable { editingStep = step; showStepDialog = true }) {
                            Text(
                                step.title, color = if (step.done) R.T3 else R.T1,
                                fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                textDecoration = if (step.done) TextDecoration.LineThrough else TextDecoration.None
                            )
                            if (step.description.isNotEmpty()) {
                                Text(step.description, color = R.T3, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                        IconButton(onClick = { vm.deleteRoadmapStep(step.id) }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, "Sil", tint = R.T3, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { editingStep = null; showStepDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = R.Red),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Adım Ekle", fontWeight = FontWeight.Bold)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(pwd.notes, key = { it.id }) { note ->
                    Column(
                        modifier = Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(R.Card)
                            .border(1.dp, R.Border, RoundedCornerShape(8.dp))
                            .clickable { editingNote = note; showNoteDialog = true }
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(note.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            IconButton(onClick = { vm.deleteNote(note.id) }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, "Sil", tint = R.T3, modifier = Modifier.size(14.dp))
                            }
                        }
                        if (note.content.isNotEmpty()) {
                            Text(note.content, color = R.T2, fontSize = 11.sp, maxLines = 3)
                        }
                        if (note.source.isNotEmpty()) {
                            RBadge(note.source, R.Li)
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { editingNote = null; showNoteDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = R.Red),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Not Ekle", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Step dialog
    if (showStepDialog) {
        var t by remember { mutableStateOf(editingStep?.title ?: "") }
        var d by remember { mutableStateOf(editingStep?.description ?: "") }
        AlertDialog(
            onDismissRequest = { showStepDialog = false },
            title = { Text(if (editingStep == null) "Yeni Adım" else "Adım Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DarkField(t, { t = it }, "Başlık")
                    DarkField(d, { d = it }, "Açıklama", singleLine = false, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val s = (editingStep ?: RoadmapStep(planId = pwd.plan.id, sortOrder = pwd.roadmap.size))
                        .copy(title = t, description = d)
                    vm.saveRoadmapStep(s); showStepDialog = false
                }, enabled = t.isNotBlank()) {
                    Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { showStepDialog = false }) { Text("İptal", color = R.T3) } },
            containerColor = R.Card, shape = RoundedCornerShape(12.dp)
        )
    }

    // Note dialog
    if (showNoteDialog) {
        var t by remember { mutableStateOf(editingNote?.title ?: "") }
        var c by remember { mutableStateOf(editingNote?.content ?: "") }
        var s by remember { mutableStateOf(editingNote?.source ?: "") }
        AlertDialog(
            onDismissRequest = { showNoteDialog = false },
            title = { Text(if (editingNote == null) "Yeni Not" else "Not Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DarkField(t, { t = it }, "Başlık")
                    DarkField(c, { c = it }, "İçerik", singleLine = false, minLines = 3)
                    DarkField(s, { s = it }, "Kaynak")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = (editingNote ?: Note(planId = pwd.plan.id, sortOrder = pwd.notes.size))
                        .copy(title = t, content = c, source = s)
                    vm.saveNote(n); showNoteDialog = false
                }, enabled = t.isNotBlank()) {
                    Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { showNoteDialog = false }) { Text("İptal", color = R.T3) } },
            containerColor = R.Card, shape = RoundedCornerShape(12.dp)
        )
    }
}
