package com.rathudan.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.ui.theme.R

// ══════ STAT CARD ══════
@Composable
fun StatCard(
    label: String,
    value: String,
    color: Color = R.Red,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(R.Card)
            .border(1.dp, R.Border, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 22.sp)
        Spacer(Modifier.height(2.dp))
        Text(label, color = R.T3, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ══════ SECTION HEADER ══════
@Composable
fun SectionHeader(
    title: String,
    action: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (action != null && onAction != null) {
            TextButton(onClick = onAction) {
                Text(action, color = R.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ══════ BADGE / TAG ══════
@Composable
fun RBadge(
    text: String,
    color: Color,
    bg: Color = color.copy(alpha = 0.08f),
    modifier: Modifier = Modifier
) {
    Text(
        text,
        color = color,
        fontSize = 9.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 0.5.sp,
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 6.dp, vertical = 3.dp)
    )
}

// ══════ EMPTY STATE ══════
@Composable
fun EmptyState(message: String, icon: @Composable () -> Unit = {}) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Spacer(Modifier.height(12.dp))
        Text(message, color = R.T3, fontSize = 12.sp)
    }
}

// ══════ LOADING STATE ══════
@Composable
fun LoadingState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = R.Red, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
    }
}

// ══════ DARK TEXT FIELD ══════
@Composable
fun DarkField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = singleLine,
        minLines = minLines,
        textStyle = TextStyle(color = R.T1, fontSize = 13.sp),
        cursorBrush = SolidColor(R.Red),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(R.Bg)
            .border(1.dp, R.Border, RoundedCornerShape(6.dp))
            .padding(12.dp),
        decorationBox = { inner ->
            if (value.isEmpty()) {
                Text(placeholder, color = R.T3, fontSize = 13.sp)
            }
            inner()
        }
    )
}

// ══════ FAB ══════
@Composable
fun RFab(onClick: () -> Unit, icon: @Composable () -> Unit = {
    Icon(Icons.Default.Add, "Ekle", tint = Color.White)
}) {
    FloatingActionButton(
        onClick = onClick,
        containerColor = R.Red,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.size(50.dp)
    ) {
        icon()
    }
}

// ══════ CONFIRM DIALOG ══════
@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = R.T1, fontWeight = FontWeight.Bold) },
        text = { Text(message, color = R.T2, fontSize = 13.sp) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Sil", color = R.Danger, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal", color = R.T3)
            }
        },
        containerColor = R.Card,
        shape = RoundedCornerShape(12.dp)
    )
}

// ══════ TOAST SNACKBAR HOST ══════
@Composable
fun RToast(snackbarHostState: SnackbarHostState) {
    SnackbarHost(hostState = snackbarHostState) { data ->
        Snackbar(
            snackbarData = data,
            containerColor = R.Card,
            contentColor = R.T1,
            actionColor = R.Red,
            shape = RoundedCornerShape(8.dp)
        )
    }
}

// ══════ PROGRESS BAR ══════
@Composable
fun RProgressBar(
    progress: Float,
    color: Color = R.Red,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(R.Border)
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
    }
}

// ══════ CHIP SELECTOR ══════
@Composable
fun ChipRow(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    colorFn: ((String) -> Color)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEach { (key, label) ->
            val isSel = selected == key
            val c = colorFn?.invoke(key) ?: R.Red
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSel) c.copy(alpha = 0.15f) else Color.Transparent)
                    .border(1.dp, if (isSel) c else R.Border, RoundedCornerShape(6.dp))
                    .clickable { onSelect(key) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(label, color = if (isSel) c else R.T3, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
