package com.rathudan.app.ui.icerik

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.rathudan.app.ui.components.LoadingState
import com.rathudan.app.ui.components.RToast
import com.rathudan.app.ui.komuta.NavItem
import com.rathudan.app.ui.theme.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IcerikShell(onBack: () -> Unit) {
    var page by remember { mutableStateOf("dash") }
    val vm: IcerikViewModel = hiltViewModel()
    val state by vm.state.collectAsState()
    val snackbarHost = remember { SnackbarHostState() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHost.showSnackbar(it)
            vm.clearError()
        }
    }

    val items = listOf(
        NavItem("dash", "Ana Sayfa", Icons.Outlined.Dashboard),
        NavItem("hesaplar", "Hesaplar", Icons.Outlined.Person),
        NavItem("icerikler", "İçerikler", Icons.Outlined.Edit),
        NavItem("sablonlar", "Şablonlar", Icons.Outlined.GridView),
        NavItem("hesap_planlari", "Planlar", Icons.Outlined.Checklist),
        NavItem("takvim", "Takvim", Icons.Outlined.CalendarMonth),
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("R", color = R.Red, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text("İÇERİK", color = R.T1, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = R.T2)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = R.Side)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = R.Side) {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = page == item.key,
                        onClick = { page = item.key },
                        icon = { Icon(item.icon, item.label) },
                        label = { Text(item.label, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = R.Red,
                            selectedTextColor = R.Red,
                            unselectedIconColor = R.T3,
                            unselectedTextColor = R.T3,
                            indicatorColor = R.Red.copy(alpha = 0.1f)
                        )
                    )
                }
            }
        },
        snackbarHost = { RToast(snackbarHost) },
        containerColor = R.Bg
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (state.isLoading) {
                LoadingState()
            } else {
                when (page) {
                    "dash" -> IcerikDashPage(state, vm)
                    "hesaplar" -> IcerikHesaplarPage(state, vm)
                    "icerikler" -> IcerikIceriklerPage(state, vm)
                    "sablonlar" -> IcerikSablonlarPage(state, vm)
                    "hesap_planlari" -> IcerikHesapPlanlariPage(state, vm)
                    "takvim" -> IcerikTakvimPage(state, vm)
                }
            }
        }
    }
}
