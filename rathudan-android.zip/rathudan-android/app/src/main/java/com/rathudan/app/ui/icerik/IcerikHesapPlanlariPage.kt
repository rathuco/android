package com.rathudan.app.ui.icerik

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.AccountPlan
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun IcerikHesapPlanlariPage(state: IcerikState, vm: IcerikViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<AccountPlan?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var filterCat by remember { mutableStateOf("all") }
    var filterAccount by remember { mutableStateOf("all") }

    val categories = listOf("strateji", "hedef_kitle", "icerik_stratejisi", "ton_ve_dil", "referans", "diger")

    val filtered = state.accountPlans.filter { p ->
        (filterCat == "all" || p.category == filterCat) &&
        (filterAccount == "all" || p.accountId == filterAccount)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Hesap Planları", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))

            // Account filter
            if (state.accounts.size > 1) {
                val accOpts = listOf("all" to "Tüm Hesaplar") + state.accounts.map { it.id to "@${it.username}" }
                ChipRow(
                    options = accOpts.take(4),
                    selected = filterAccount, onSelect = { filterAccount = it }
                )
                Spacer(Modifier.height(6.dp))
            }

            // Category filter
            ChipRow(
                options = listOf("all" to "Tümü") + categories.map { it to R.categoryLabel(it) },
                selected = filterCat, onSelect = { filterCat = it },
                colorFn = { if (it == "all") R.Red else R.categoryColor(it) }
            )
            Spacer(Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState("Henüz hesap planı yok")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { plan ->
                        val acc = state.accounts.find { it.id == plan.accountId }
                        Column(
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(R.Card)
                                .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                .clickable { editing = plan; showDialog = true }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    RBadge(R.categoryLabel(plan.category), R.categoryColor(plan.category))
                                    if (plan.pinned) RBadge("📌", R.Warn)
                                    acc?.let {
                                        RBadge(R.platformTag(it.platform), R.platformColor(it.platform), R.platformBg(it.platform))
                                    }
                                }
                                IconButton(onClick = { deleteTarget = plan.id }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text(plan.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            if (plan.content.isNotEmpty()) {
                                Text(plan.content, color = R.T2, fontSize = 11.sp, maxLines = 3)
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { editing = null; showDialog = true })
        }

        if (showDialog) {
            AccountPlanDialog(
                initial = editing,
                accounts = state.accounts,
                onSave = { vm.saveAccountPlan(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Planı Sil", message = "Bu hesap planı silinecek.",
                onConfirm = { vm.deleteAccountPlan(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun AccountPlanDialog(
    initial: AccountPlan?,
    accounts: List<com.rathudan.app.data.model.Account>,
    onSave: (AccountPlan) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var content by remember { mutableStateOf(initial?.content ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "strateji") }
    var pinned by remember { mutableStateOf(initial?.pinned ?: false) }
    var accountId by remember { mutableStateOf(initial?.accountId ?: accounts.firstOrNull()?.id ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni Plan" else "Plan Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (accounts.isNotEmpty()) {
                    Text("Hesap", color = R.T3, fontSize = 10.sp)
                    ChipRow(
                        options = accounts.map { it.id to "@${it.username}" },
                        selected = accountId, onSelect = { accountId = it },
                        colorFn = { id -> accounts.find { it.id == id }?.let { R.platformColor(it.platform) } ?: R.T3 }
                    )
                }

                Text("Kategori", color = R.T3, fontSize = 10.sp)
                ChipRow(
                    options = listOf(
                        "strateji" to "Strateji", "hedef_kitle" to "Hedef Kitle",
                        "icerik_stratejisi" to "İçerik"
                    ),
                    selected = category, onSelect = { category = it },
                    colorFn = { R.categoryColor(it) }
                )
                ChipRow(
                    options = listOf(
                        "ton_ve_dil" to "Ton & Dil", "referans" to "Referans", "diger" to "Diğer"
                    ),
                    selected = category, onSelect = { category = it },
                    colorFn = { R.categoryColor(it) }
                )

                DarkField(title, { title = it }, "Başlık")
                DarkField(content, { content = it }, "İçerik", singleLine = false, minLines = 3)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = pinned,
                        onCheckedChange = { pinned = it },
                        colors = CheckboxDefaults.colors(checkedColor = R.Warn, uncheckedColor = R.T3)
                    )
                    Text("Sabitlenmiş", color = R.T2, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = (initial ?: AccountPlan()).copy(
                    title = title, content = content, category = category,
                    pinned = pinned, accountId = accountId
                )
                onSave(p)
            }, enabled = title.isNotBlank()) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
