package com.rathudan.app.ui.icerik

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun IcerikDashPage(state: IcerikState, vm: IcerikViewModel) {
    val totalAccounts = state.accounts.size
    val totalContents = state.contents.size
    val drafts = state.contents.count { it.status == "taslak" }
    val published = state.contents.count { it.status == "yayinlandi" }
    val ready = state.contents.count { it.status == "hazir" }
    val totalTemplates = state.templates.size

    val byPlatform = state.contents.groupBy { it.platform }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("İçerik Merkezi", color = R.T1, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text("Tüm içerik operasyonlarınız", color = R.T3, fontSize = 12.sp)

        // Stats
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Hesap", "$totalAccounts", R.Li, Modifier.weight(1f))
            StatCard("İçerik", "$totalContents", R.Red, Modifier.weight(1f))
            StatCard("Şablon", "$totalTemplates", R.Purple, Modifier.weight(1f))
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Taslak", "$drafts", R.Warn, Modifier.weight(1f))
            StatCard("Hazır", "$ready", R.Li, Modifier.weight(1f))
            StatCard("Yayında", "$published", R.Ok, Modifier.weight(1f))
        }

        // Platform breakdown
        if (byPlatform.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(R.Card)
                    .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Platform Dağılımı", color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                byPlatform.forEach { (platform, items) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            RBadge(R.platformTag(platform), R.platformColor(platform), R.platformBg(platform))
                            Text(platform.replaceFirstChar { it.uppercase() }, color = R.T2, fontSize = 12.sp)
                        }
                        Text("${items.size}", color = R.T1, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    RProgressBar(
                        progress = items.size.toFloat() / totalContents.coerceAtLeast(1),
                        color = R.platformColor(platform)
                    )
                }
            }
        }

        // Recent contents
        if (state.contents.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(R.Card)
                    .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Son İçerikler", color = R.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                state.contents.take(5).forEach { c ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                            RBadge(R.platformTag(c.platform), R.platformColor(c.platform), R.platformBg(c.platform))
                            Text(c.title, color = R.T2, fontSize = 11.sp, maxLines = 1)
                        }
                        RBadge(R.statusLabel(c.status), R.statusColor(c.status))
                    }
                }
            }
        }
    }
}
