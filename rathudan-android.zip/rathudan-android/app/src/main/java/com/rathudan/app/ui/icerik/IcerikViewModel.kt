package com.rathudan.app.ui.icerik

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rathudan.app.data.model.*
import com.rathudan.app.data.repository.RathudanRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class IcerikState(
    val accounts: List<Account> = emptyList(),
    val contents: List<Content> = emptyList(),
    val templates: List<ContentTemplate> = emptyList(),
    val accountPlans: List<AccountPlan> = emptyList(),
    val calendarEvents: List<CalendarEvent> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class IcerikViewModel @Inject constructor(
    private val repo: RathudanRepository
) : ViewModel() {
    private val _state = MutableStateFlow(IcerikState())
    val state: StateFlow<IcerikState> = _state.asStateFlow()

    init { loadAll() }

    fun loadAll() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val accounts = repo.fetchAccounts()
                val contents = repo.fetchContents()
                val templates = repo.fetchTemplates()
                val plans = repo.fetchAccountPlans()
                val events = repo.fetchCalendarEvents()
                _state.value = IcerikState(
                    accounts = accounts, contents = contents, templates = templates,
                    accountPlans = plans, calendarEvents = events, isLoading = false
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    // Accounts
    fun addAccount(account: Account) {
        viewModelScope.launch {
            try {
                val saved = repo.insertAccount(account)
                _state.value = _state.value.copy(accounts = _state.value.accounts + saved)
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    fun deleteAccount(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteAccount(id)
                _state.value = _state.value.copy(accounts = _state.value.accounts.filter { it.id != id })
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    // Contents
    fun saveContent(content: Content) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertContent(content)
                val list = _state.value.contents.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(0, saved)
                _state.value = _state.value.copy(contents = list)
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    fun deleteContent(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteContent(id)
                _state.value = _state.value.copy(contents = _state.value.contents.filter { it.id != id })
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    // Templates
    fun saveTemplate(tmpl: ContentTemplate) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertTemplate(tmpl)
                val list = _state.value.templates.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(saved)
                _state.value = _state.value.copy(templates = list)
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    fun deleteTemplate(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteTemplate(id)
                _state.value = _state.value.copy(templates = _state.value.templates.filter { it.id != id })
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    // Account Plans
    fun saveAccountPlan(plan: AccountPlan) {
        viewModelScope.launch {
            try {
                val saved = repo.upsertAccountPlan(plan)
                val list = _state.value.accountPlans.toMutableList()
                val idx = list.indexOfFirst { it.id == saved.id }
                if (idx >= 0) list[idx] = saved else list.add(saved)
                _state.value = _state.value.copy(accountPlans = list)
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    fun deleteAccountPlan(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteAccountPlan(id)
                _state.value = _state.value.copy(accountPlans = _state.value.accountPlans.filter { it.id != id })
            } catch (e: Exception) { _state.value = _state.value.copy(error = e.message) }
        }
    }

    fun clearError() { _state.value = _state.value.copy(error = null) }
}
