package com.rathudan.app.ui.komuta

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.NotePage
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun KomutaNotlarPage(state: KomutaState, vm: KomutaViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<NotePage?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var selectedPage by remember { mutableStateOf<NotePage?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        if (selectedPage == null) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text("Notlar", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))

                if (state.notePages.isEmpty()) {
                    EmptyState("Henüz not sayfası yok")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(state.notePages, key = { it.id }) { page ->
                            Column(
                                modifier = Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(R.Card)
                                    .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                    .clickable { selectedPage = page }
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(page.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                        modifier = Modifier.weight(1f))
                                    IconButton(onClick = { deleteTarget = page.id }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                                    }
                                }
                                if (page.description.isNotEmpty()) {
                                    Text(page.description, color = R.T2, fontSize = 11.sp, maxLines = 2)
                                }
                                if (page.source.isNotEmpty()) RBadge(page.source, R.Li)
                            }
                        }
                    }
                }
            }

            Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
                RFab(onClick = { editing = null; showDialog = true })
            }
        } else {
            // Detail view
            NotePageDetail(
                page = selectedPage!!,
                onBack = { selectedPage = null },
                onSave = { vm.saveNotePage(it); selectedPage = it },
                onDelete = { vm.deleteNotePage(it); selectedPage = null }
            )
        }

        if (showDialog) {
            NotePageDialog(
                initial = editing,
                onSave = { vm.saveNotePage(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Notu Sil", message = "Bu not kalıcı olarak silinecek.",
                onConfirm = { vm.deleteNotePage(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun NotePageDetail(page: NotePage, onBack: () -> Unit, onSave: (NotePage) -> Unit, onDelete: (String) -> Unit) {
    var title by remember(page.id) { mutableStateOf(page.title) }
    var content by remember(page.id) { mutableStateOf(page.content) }
    var changed by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                if (changed) onSave(page.copy(title = title, content = content))
                onBack()
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = R.T2)
            }
            DarkField(title, { title = it; changed = true }, "Başlık", modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        if (page.source.isNotEmpty()) {
            RBadge(page.source, R.Li)
            Spacer(Modifier.height(8.dp))
        }
        DarkField(
            content, { content = it; changed = true }, "İçerik yazın...",
            singleLine = false, minLines = 15,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onSave(page.copy(title = title, content = content)); changed = false },
                colors = ButtonDefaults.buttonColors(containerColor = R.Red),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f),
                enabled = changed
            ) {
                Text("Kaydet", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { onDelete(page.id) },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = R.Danger)
            ) {
                Icon(Icons.Default.Delete, "Sil", modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun NotePageDialog(initial: NotePage?, onSave: (NotePage) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var source by remember { mutableStateOf(initial?.source ?: "") }
    var content by remember { mutableStateOf(initial?.content ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni Not" else "Not Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DarkField(title, { title = it }, "Başlık")
                DarkField(desc, { desc = it }, "Açıklama")
                DarkField(source, { source = it }, "Kaynak")
                DarkField(content, { content = it }, "İçerik", singleLine = false, minLines = 3)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = (initial ?: NotePage()).copy(title = title, description = desc, source = source, content = content)
                onSave(p)
            }, enabled = title.isNotBlank()) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
