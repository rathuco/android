package com.rathudan.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ══════ ENTITIES ══════

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val platform: String,
    val accountName: String,
    val username: String,
    val createdAt: String
)

@Entity(tableName = "contents")
data class ContentEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val accountId: String,
    val platform: String,
    val title: String,
    val description: String,
    val format: String,
    val hashtags: String,
    val status: String,
    val date: String?,
    val createdAt: String,
    val updatedAt: String
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val description: String,
    val deadline: String?,
    val progress: Int,
    val status: String,
    val priority: String,
    val createdAt: String,
    val updatedAt: String
)

@Entity(tableName = "journal_entries")
data class JournalEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val date: String,
    val content: String,
    val mood: String,
    val tags: String,
    val createdAt: String,
    val updatedAt: String
)

@Entity(tableName = "plans")
data class PlanEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val createdAt: String,
    val updatedAt: String
)

@Entity(tableName = "roadmap_steps")
data class RoadmapStepEntity(
    @PrimaryKey val id: String,
    val planId: String,
    val title: String,
    val description: String,
    val done: Boolean,
    val sortOrder: Int,
    val createdAt: String
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val planId: String,
    val title: String,
    val content: String,
    val source: String,
    val sortOrder: Int,
    val createdAt: String
)

@Entity(tableName = "note_pages")
data class NotePageEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val description: String,
    val content: String,
    val source: String,
    val sortOrder: Int,
    val createdAt: String,
    val updatedAt: String
)

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val description: String,
    val date: String,
    val time: String,
    val color: String,
    val createdAt: String
)

@Entity(tableName = "account_plans")
data class AccountPlanEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val accountId: String,
    val category: String,
    val title: String,
    val content: String,
    val pinned: Boolean,
    val sortOrder: Int,
    val createdAt: String,
    val updatedAt: String
)

@Entity(tableName = "content_templates")
data class ContentTemplateEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val platform: String,
    val name: String,
    val format: String,
    val titleTemplate: String,
    val descriptionTemplate: String,
    val hashtags: String,
    val createdAt: String,
    val updatedAt: String
)

// ══════ DAO ══════

@Dao
interface RathudanDao {
    // Goals
    @Query("SELECT * FROM goals WHERE userId = :uid ORDER BY createdAt DESC")
    fun getGoals(uid: String): Flow<List<GoalEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(items: List<GoalEntity>)
    @Query("DELETE FROM goals WHERE userId = :uid")
    suspend fun clearGoals(uid: String)

    // Journal
    @Query("SELECT * FROM journal_entries WHERE userId = :uid ORDER BY date DESC")
    fun getJournal(uid: String): Flow<List<JournalEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournal(items: List<JournalEntity>)
    @Query("DELETE FROM journal_entries WHERE userId = :uid")
    suspend fun clearJournal(uid: String)

    // Plans
    @Query("SELECT * FROM plans WHERE userId = :uid ORDER BY createdAt")
    fun getPlans(uid: String): Flow<List<PlanEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlans(items: List<PlanEntity>)
    @Query("DELETE FROM plans WHERE userId = :uid")
    suspend fun clearPlans(uid: String)

    // Roadmap Steps
    @Query("SELECT * FROM roadmap_steps WHERE planId IN (:planIds) ORDER BY sortOrder")
    suspend fun getRoadmapSteps(planIds: List<String>): List<RoadmapStepEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoadmapSteps(items: List<RoadmapStepEntity>)

    // Notes
    @Query("SELECT * FROM notes WHERE planId IN (:planIds) ORDER BY sortOrder")
    suspend fun getNotes(planIds: List<String>): List<NoteEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(items: List<NoteEntity>)

    // Note Pages
    @Query("SELECT * FROM note_pages WHERE userId = :uid ORDER BY sortOrder")
    fun getNotePages(uid: String): Flow<List<NotePageEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotePages(items: List<NotePageEntity>)
    @Query("DELETE FROM note_pages WHERE userId = :uid")
    suspend fun clearNotePages(uid: String)

    // Calendar Events
    @Query("SELECT * FROM calendar_events WHERE userId = :uid ORDER BY date")
    fun getCalendarEvents(uid: String): Flow<List<CalendarEventEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarEvents(items: List<CalendarEventEntity>)
    @Query("DELETE FROM calendar_events WHERE userId = :uid")
    suspend fun clearCalendarEvents(uid: String)

    // Accounts
    @Query("SELECT * FROM accounts WHERE userId = :uid ORDER BY createdAt")
    fun getAccounts(uid: String): Flow<List<AccountEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(items: List<AccountEntity>)
    @Query("DELETE FROM accounts WHERE userId = :uid")
    suspend fun clearAccounts(uid: String)

    // Contents
    @Query("SELECT * FROM contents WHERE userId = :uid ORDER BY createdAt DESC")
    fun getContents(uid: String): Flow<List<ContentEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContents(items: List<ContentEntity>)
    @Query("DELETE FROM contents WHERE userId = :uid")
    suspend fun clearContents(uid: String)

    // Account Plans
    @Query("SELECT * FROM account_plans WHERE userId = :uid ORDER BY pinned DESC, sortOrder")
    fun getAccountPlans(uid: String): Flow<List<AccountPlanEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccountPlans(items: List<AccountPlanEntity>)
    @Query("DELETE FROM account_plans WHERE userId = :uid")
    suspend fun clearAccountPlans(uid: String)

    // Templates
    @Query("SELECT * FROM content_templates WHERE userId = :uid ORDER BY createdAt")
    fun getTemplates(uid: String): Flow<List<ContentTemplateEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplates(items: List<ContentTemplateEntity>)
    @Query("DELETE FROM content_templates WHERE userId = :uid")
    suspend fun clearTemplates(uid: String)
}

// ══════ DATABASE ══════

@Database(
    entities = [
        AccountEntity::class, ContentEntity::class, GoalEntity::class,
        JournalEntity::class, PlanEntity::class, RoadmapStepEntity::class,
        NoteEntity::class, NotePageEntity::class, CalendarEventEntity::class,
        AccountPlanEntity::class, ContentTemplateEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RathudanDatabase : RoomDatabase() {
    abstract fun dao(): RathudanDao
}
