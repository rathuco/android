package com.rathudan.app.ui.icerik

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.Content
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun IcerikIceriklerPage(state: IcerikState, vm: IcerikViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Content?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var filterStatus by remember { mutableStateOf("all") }
    var filterPlatform by remember { mutableStateOf("all") }

    val filtered = state.contents.filter { c ->
        (filterStatus == "all" || c.status == filterStatus) &&
        (filterPlatform == "all" || c.platform == filterPlatform)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("İçerikler", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))

            // Filters
            ChipRow(
                options = listOf("all" to "Tümü", "taslak" to "Taslak", "hazir" to "Hazır", "yayinlandi" to "Yayında"),
                selected = filterStatus, onSelect = { filterStatus = it },
                colorFn = { if (it == "all") R.Red else R.statusColor(it) }
            )
            Spacer(Modifier.height(6.dp))
            ChipRow(
                options = listOf("all" to "Tüm Platformlar", "instagram" to "IG", "linkedin" to "LI", "youtube" to "YT"),
                selected = filterPlatform, onSelect = { filterPlatform = it },
                colorFn = { if (it == "all") R.T2 else R.platformColor(it) }
            )
            Spacer(Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState("İçerik bulunamadı")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { content ->
                        val acc = state.accounts.find { it.id == content.accountId }
                        Column(
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(R.Card)
                                .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                .clickable { editing = content; showDialog = true }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    RBadge(R.platformTag(content.platform), R.platformColor(content.platform), R.platformBg(content.platform))
                                    RBadge(R.statusLabel(content.status), R.statusColor(content.status))
                                    if (content.format.isNotEmpty()) RBadge(content.format, R.T3)
                                }
                                IconButton(onClick = { deleteTarget = content.id }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text(content.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            if (content.description.isNotEmpty()) {
                                Text(content.description, color = R.T2, fontSize = 11.sp, maxLines = 2)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                acc?.let { Text("@${it.username}", color = R.T3, fontSize = 10.sp) }
                                content.date?.let { Text(it, color = R.T3, fontSize = 10.sp) }
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { editing = null; showDialog = true })
        }

        if (showDialog) {
            ContentDialog(
                initial = editing,
                accounts = state.accounts,
                onSave = { vm.saveContent(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "İçeriği Sil", message = "Bu içerik kalıcı olarak silinecek.",
                onConfirm = { vm.deleteContent(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun ContentDialog(
    initial: Content?,
    accounts: List<com.rathudan.app.data.model.Account>,
    onSave: (Content) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var format by remember { mutableStateOf(initial?.format ?: "") }
    var hashtags by remember { mutableStateOf(initial?.hashtags ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: "taslak") }
    var date by remember { mutableStateOf(initial?.date ?: "") }
    var accountId by remember { mutableStateOf(initial?.accountId ?: accounts.firstOrNull()?.id ?: "") }
    var platform by remember { mutableStateOf(initial?.platform ?: accounts.firstOrNull()?.platform ?: "instagram") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni İçerik" else "İçerik Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.heightIn(max = 420.dp)
                    .imePadding()
            ) {
                // Account selector
                if (accounts.isNotEmpty()) {
                    Text("Hesap", color = R.T3, fontSize = 10.sp)
                    ChipRow(
                        options = accounts.map { it.id to "${R.platformTag(it.platform)} @${it.username}" },
                        selected = accountId,
                        onSelect = { id ->
                            accountId = id
                            accounts.find { it.id == id }?.let { platform = it.platform }
                        },
                        colorFn = { id -> accounts.find { it.id == id }?.let { R.platformColor(it.platform) } ?: R.T3 }
                    )
                }

                DarkField(title, { title = it }, "Başlık")
                DarkField(desc, { desc = it }, "Açıklama", singleLine = false, minLines = 2)
                DarkField(format, { format = it }, "Format (reel, post, story...)")
                DarkField(hashtags, { hashtags = it }, "Hashtagler")
                DarkField(date, { date = it }, "Tarih (YYYY-MM-DD)")

                Text("Durum", color = R.T3, fontSize = 10.sp)
                ChipRow(
                    options = listOf("taslak" to "Taslak", "hazir" to "Hazır", "yayinlandi" to "Yayında"),
                    selected = status, onSelect = { status = it },
                    colorFn = { R.statusColor(it) }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val c = (initial ?: Content()).copy(
                    title = title, description = desc, format = format,
                    hashtags = hashtags, status = status,
                    date = date.ifBlank { null },
                    accountId = accountId, platform = platform
                )
                onSave(c)
            }, enabled = title.isNotBlank()) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
