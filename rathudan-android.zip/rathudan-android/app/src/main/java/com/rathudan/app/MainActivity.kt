package com.rathudan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rathudan.app.ui.auth.AuthScreen
import com.rathudan.app.ui.auth.AuthViewModel
import com.rathudan.app.ui.auth.ModuleSelectorScreen
import com.rathudan.app.ui.komuta.KomutaShell
import com.rathudan.app.ui.icerik.IcerikShell
import com.rathudan.app.ui.theme.R
import com.rathudan.app.ui.theme.RathudanTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            RathudanTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = R.Bg
                ) {
                    val navController = rememberNavController()
                    val authVm: AuthViewModel = hiltViewModel()
                    val authState by authVm.state.collectAsState()

                    val startDest = if (authState.isLoggedIn) "module_select" else "auth"

                    NavHost(navController = navController, startDestination = startDest) {
                        composable("auth") {
                            AuthScreen(
                                onLoggedIn = {
                                    navController.navigate("module_select") {
                                        popUpTo("auth") { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable("module_select") {
                            ModuleSelectorScreen(
                                onSelect = { module ->
                                    navController.navigate(module)
                                },
                                onLogout = {
                                    authVm.signOut()
                                    navController.navigate("auth") {
                                        popUpTo(0) { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable("komuta") {
                            KomutaShell(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("icerik") {
                            IcerikShell(
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
