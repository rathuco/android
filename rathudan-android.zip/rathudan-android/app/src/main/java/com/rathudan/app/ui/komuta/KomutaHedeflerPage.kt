package com.rathudan.app.ui.komuta

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.Goal
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun KomutaHedeflerPage(state: KomutaState, vm: KomutaViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Goal?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("all") }

    val filtered = when (filter) {
        "aktif" -> state.goals.filter { it.status == "aktif" }
        "tamamlandi" -> state.goals.filter { it.status == "tamamlandi" }
        "iptal" -> state.goals.filter { it.status == "iptal" }
        else -> state.goals
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Hedefler", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))

            // Filter chips
            ChipRow(
                options = listOf("all" to "Tümü", "aktif" to "Aktif", "tamamlandi" to "Tamamlandı", "iptal" to "İptal"),
                selected = filter,
                onSelect = { filter = it },
                colorFn = { if (it == "all") R.Red else R.goalStatusColor(it) }
            )
            Spacer(Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState("Henüz hedef yok")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { goal ->
                        GoalCard(
                            goal = goal,
                            onEdit = { editing = goal; showDialog = true },
                            onDelete = { deleteTarget = goal.id }
                        )
                    }
                }
            }
        }

        // FAB
        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { editing = null; showDialog = true })
        }

        // Dialog
        if (showDialog) {
            GoalDialog(
                initial = editing,
                onSave = { vm.saveGoal(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        // Delete confirm
        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Hedefi Sil",
                message = "Bu hedef kalıcı olarak silinecek.",
                onConfirm = { vm.deleteGoal(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun GoalCard(goal: Goal, onEdit: () -> Unit, onDelete: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(R.Card)
            .border(1.dp, R.Border, RoundedCornerShape(10.dp))
            .clickable(onClick = onEdit)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                RBadge(R.goalStatusLabel(goal.status), R.goalStatusColor(goal.status))
                RBadge(R.priorityLabel(goal.priority), R.priorityColor(goal.priority))
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
            }
        }
        Text(goal.title, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (goal.description.isNotEmpty()) {
            Text(goal.description, color = R.T2, fontSize = 11.sp, maxLines = 2)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("%${goal.progress}", color = R.T3, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            goal.deadline?.let {
                Text(it, color = R.T3, fontSize = 10.sp)
            }
        }
        RProgressBar(progress = goal.progress / 100f, color = R.priorityColor(goal.priority))
    }
}

@Composable
fun GoalDialog(initial: Goal?, onSave: (Goal) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var deadline by remember { mutableStateOf(initial?.deadline ?: "") }
    var progress by remember { mutableStateOf((initial?.progress ?: 0).toFloat()) }
    var status by remember { mutableStateOf(initial?.status ?: "aktif") }
    var priority by remember { mutableStateOf(initial?.priority ?: "normal") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni Hedef" else "Hedef Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DarkField(title, { title = it }, "Başlık")
                DarkField(desc, { desc = it }, "Açıklama", singleLine = false, minLines = 2)
                DarkField(deadline, { deadline = it }, "Son tarih (YYYY-MM-DD)")

                Text("İlerleme: %${progress.toInt()}", color = R.T2, fontSize = 11.sp)
                Slider(
                    value = progress,
                    onValueChange = { progress = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(thumbColor = R.Red, activeTrackColor = R.Red)
                )

                Text("Durum", color = R.T3, fontSize = 10.sp)
                ChipRow(
                    options = listOf("aktif" to "Aktif", "tamamlandi" to "Tamamlandı", "iptal" to "İptal"),
                    selected = status, onSelect = { status = it },
                    colorFn = { R.goalStatusColor(it) }
                )

                Text("Öncelik", color = R.T3, fontSize = 10.sp)
                ChipRow(
                    options = listOf("dusuk" to "Düşük", "normal" to "Normal", "yuksek" to "Yüksek", "kritik" to "Kritik"),
                    selected = priority, onSelect = { priority = it },
                    colorFn = { R.priorityColor(it) }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val g = (initial ?: Goal()).copy(
                        title = title, description = desc,
                        deadline = deadline.ifBlank { null },
                        progress = progress.toInt(),
                        status = status, priority = priority
                    )
                    onSave(g)
                },
                enabled = title.isNotBlank()
            ) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) }
        },
        containerColor = R.Card,
        shape = RoundedCornerShape(12.dp)
    )
}
