package com.rathudan.app.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Account(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val platform: String = "instagram",
    @SerialName("account_name") val accountName: String = "",
    val username: String = "",
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class Content(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    @SerialName("account_id") val accountId: String = "",
    val platform: String = "instagram",
    val title: String = "",
    val description: String = "",
    val format: String = "",
    val hashtags: String = "",
    val status: String = "taslak",
    val date: String? = null,
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class AccountPlan(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    @SerialName("account_id") val accountId: String = "",
    val category: String = "strateji",
    val title: String = "",
    val content: String = "",
    val pinned: Boolean = false,
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class ContentTemplate(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val platform: String = "instagram",
    val name: String = "",
    val format: String = "",
    @SerialName("title_template") val titleTemplate: String = "",
    @SerialName("description_template") val descriptionTemplate: String = "",
    val hashtags: String = "",
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class Plan(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val title: String = "",
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class RoadmapStep(
    val id: String = "",
    @SerialName("plan_id") val planId: String = "",
    val title: String = "",
    val description: String = "",
    val done: Boolean = false,
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class Note(
    val id: String = "",
    @SerialName("plan_id") val planId: String = "",
    val title: String = "",
    val content: String = "",
    val source: String = "",
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class NotePage(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val title: String = "",
    val description: String = "",
    val content: String = "",
    val source: String = "",
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class CalendarEvent(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val title: String = "",
    val description: String = "",
    val date: String = "",
    val time: String = "",
    val color: String = "#C2212E",
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class Goal(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val title: String = "",
    val description: String = "",
    val deadline: String? = null,
    val progress: Int = 0,
    val status: String = "aktif",
    val priority: String = "normal",
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class JournalEntry(
    val id: String = "",
    @SerialName("user_id") val userId: String = "",
    val date: String = "",
    val content: String = "",
    val mood: String = "",
    val tags: String = "",
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = ""
)

// Aggregated plan with children
data class PlanWithDetails(
    val plan: Plan,
    val roadmap: List<RoadmapStep> = emptyList(),
    val notes: List<Note> = emptyList()
)
