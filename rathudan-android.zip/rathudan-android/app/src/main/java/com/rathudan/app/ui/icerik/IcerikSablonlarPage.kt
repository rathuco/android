package com.rathudan.app.ui.icerik

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rathudan.app.data.model.Content
import com.rathudan.app.data.model.ContentTemplate
import com.rathudan.app.ui.components.*
import com.rathudan.app.ui.theme.R

@Composable
fun IcerikSablonlarPage(state: IcerikState, vm: IcerikViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ContentTemplate?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Şablonlar", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Text("İçerikleriniz için hazır şablonlar", color = R.T3, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))

            if (state.templates.isEmpty()) {
                EmptyState("Henüz şablon yok")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.templates, key = { it.id }) { tmpl ->
                        Column(
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(R.Card)
                                .border(1.dp, R.Border, RoundedCornerShape(10.dp))
                                .clickable { editing = tmpl; showDialog = true }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    RBadge(R.platformTag(tmpl.platform), R.platformColor(tmpl.platform), R.platformBg(tmpl.platform))
                                    if (tmpl.format.isNotEmpty()) RBadge(tmpl.format, R.T3)
                                }
                                Row {
                                    // Use template → create content
                                    IconButton(onClick = {
                                        val content = Content(
                                            platform = tmpl.platform,
                                            title = tmpl.titleTemplate,
                                            description = tmpl.descriptionTemplate,
                                            format = tmpl.format,
                                            hashtags = tmpl.hashtags
                                        )
                                        vm.saveContent(content)
                                    }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.ContentCopy, "Kullan", tint = R.Li, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(onClick = { deleteTarget = tmpl.id }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Delete, "Sil", tint = R.T3, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            Text(tmpl.name, color = R.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            if (tmpl.titleTemplate.isNotEmpty()) {
                                Text("Başlık: ${tmpl.titleTemplate}", color = R.T2, fontSize = 11.sp, maxLines = 1)
                            }
                            if (tmpl.hashtags.isNotEmpty()) {
                                Text(tmpl.hashtags, color = R.T3, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            RFab(onClick = { editing = null; showDialog = true })
        }

        if (showDialog) {
            TemplateDialog(
                initial = editing,
                onSave = { vm.saveTemplate(it); showDialog = false },
                onDismiss = { showDialog = false }
            )
        }

        deleteTarget?.let { id ->
            ConfirmDialog(
                title = "Şablonu Sil", message = "Bu şablon kalıcı olarak silinecek.",
                onConfirm = { vm.deleteTemplate(id); deleteTarget = null },
                onDismiss = { deleteTarget = null }
            )
        }
    }
}

@Composable
fun TemplateDialog(initial: ContentTemplate?, onSave: (ContentTemplate) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var platform by remember { mutableStateOf(initial?.platform ?: "instagram") }
    var format by remember { mutableStateOf(initial?.format ?: "") }
    var titleTmpl by remember { mutableStateOf(initial?.titleTemplate ?: "") }
    var descTmpl by remember { mutableStateOf(initial?.descriptionTemplate ?: "") }
    var hashtags by remember { mutableStateOf(initial?.hashtags ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni Şablon" else "Şablon Düzenle", color = R.T1, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DarkField(name, { name = it }, "Şablon adı")

                Text("Platform", color = R.T3, fontSize = 10.sp)
                ChipRow(
                    options = listOf("instagram" to "IG", "linkedin" to "LI", "youtube" to "YT"),
                    selected = platform, onSelect = { platform = it },
                    colorFn = { R.platformColor(it) }
                )

                DarkField(format, { format = it }, "Format")
                DarkField(titleTmpl, { titleTmpl = it }, "Başlık şablonu")
                DarkField(descTmpl, { descTmpl = it }, "Açıklama şablonu", singleLine = false, minLines = 2)
                DarkField(hashtags, { hashtags = it }, "Hashtagler")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val t = (initial ?: ContentTemplate()).copy(
                    name = name, platform = platform, format = format,
                    titleTemplate = titleTmpl, descriptionTemplate = descTmpl, hashtags = hashtags
                )
                onSave(t)
            }, enabled = name.isNotBlank()) {
                Text("Kaydet", color = R.Red, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal", color = R.T3) } },
        containerColor = R.Card, shape = RoundedCornerShape(12.dp)
    )
}
