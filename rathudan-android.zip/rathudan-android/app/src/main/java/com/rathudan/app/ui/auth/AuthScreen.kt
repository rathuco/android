package com.rathudan.app.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rathudan.app.data.repository.RathudanRepository
import com.rathudan.app.ui.theme.R
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthState(
    val isLoggedIn: Boolean = false,
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repo: RathudanRepository
) : ViewModel() {
    private val _state = MutableStateFlow(AuthState())
    val state: StateFlow<AuthState> = _state.asStateFlow()

    init {
        _state.value = AuthState(isLoggedIn = repo.isLoggedIn(), isLoading = false)
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                repo.signIn(email, password)
                _state.value = _state.value.copy(isLoggedIn = true, isLoading = false)
            } catch (e: Exception) {
                _state.value = _state.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun signUp(email: String, password: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                repo.signUp(email, password)
                _state.value = _state.value.copy(isLoading = false, error = "Kayıt başarılı!")
            } catch (e: Exception) {
                _state.value = _state.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            repo.signOut()
            _state.value = AuthState(isLoggedIn = false, isLoading = false)
        }
    }
}

@Composable
fun AuthScreen(onLoggedIn: () -> Unit) {
    val vm: AuthViewModel = hiltViewModel()
    val state by vm.state.collectAsState()
    var mode by remember { mutableStateOf("login") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    LaunchedEffect(state.isLoggedIn) {
        if (state.isLoggedIn) onLoggedIn()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(R.Bg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 380.dp)
                .padding(24.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(R.Side)
                .border(1.dp, R.Border, RoundedCornerShape(12.dp))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(R.Red),
                contentAlignment = Alignment.Center
            ) {
                Text("R", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text("RATHUDAN", color = R.T1, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Text("Komuta Merkezi", color = R.T3, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp)
            Spacer(Modifier.height(24.dp))

            // Tab
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(R.Bg)
                    .padding(3.dp)
            ) {
                listOf("login" to "GİRİŞ", "register" to "KAYIT").forEach { (k, l) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (mode == k) R.Red else Color.Transparent)
                            .clickable { mode = k }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(l, color = if (mode == k) Color.White else R.T3,
                            fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            // Fields
            OutlinedTextField(
                value = email, onValueChange = { email = it },
                label = { Text("E-posta") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = R.Red,
                    unfocusedBorderColor = R.Border,
                    focusedTextColor = R.T1,
                    unfocusedTextColor = R.T1
                )
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = pass, onValueChange = { pass = it },
                label = { Text("Şifre") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = R.Red,
                    unfocusedBorderColor = R.Border,
                    focusedTextColor = R.T1,
                    unfocusedTextColor = R.T1
                )
            )
            Spacer(Modifier.height(12.dp))

            // Error
            state.error?.let { msg ->
                val isSuccess = msg.contains("başarılı")
                Text(
                    msg,
                    color = if (isSuccess) R.Ok else R.Danger,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSuccess) R.OkBg else Color(0x1AEF4444))
                        .padding(8.dp)
                )
                Spacer(Modifier.height(8.dp))
            }

            // Button
            Button(
                onClick = {
                    if (mode == "login") vm.signIn(email, pass) else vm.signUp(email, pass)
                },
                enabled = !state.isLoading && email.isNotBlank() && pass.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = R.Red),
                shape = RoundedCornerShape(6.dp)
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text(
                        if (mode == "login") "GİRİŞ YAP" else "KAYIT OL",
                        fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun ModuleSelectorScreen(onSelect: (String) -> Unit, onLogout: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(R.Bg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.widthIn(max = 500.dp).padding(24.dp)
        ) {
            Box(
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(R.Red),
                contentAlignment = Alignment.Center
            ) {
                Text("R", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text("RATHUDAN KOMUTA MERKEZİ", color = R.T1, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text("Modül seçin", color = R.T3, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(32.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                listOf(
                    Triple("komuta", "Komuta Merkezi", "Planlar, hedefler, notlar, günlük ve takvim"),
                    Triple("icerik", "İçerik Merkezi", "Hesaplar, içerikler, şablonlar ve yayın takvimi")
                ).forEach { (id, title, desc) ->
                    Card(
                        modifier = Modifier.weight(1f).aspectRatio(0.9f)
                            .clickable { onSelect(id) },
                        colors = CardDefaults.cardColors(containerColor = R.Card),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(if (id == "komuta") "⚙️" else "📱", fontSize = 28.sp)
                            Spacer(Modifier.height(12.dp))
                            Text(title, color = R.T1, fontWeight = FontWeight.Black, fontSize = 15.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(desc, color = R.T3, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
            TextButton(onClick = onLogout) {
                Text("Çıkış Yap", color = R.T3, fontSize = 12.sp)
            }
        }
    }
}
